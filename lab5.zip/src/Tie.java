
class Tie extends SpaceShip{

   public Tie() {

      shields = 500;
      weapon  = 20;
   }
   public String toString() {
	   return "Tie";
   }

   
}
