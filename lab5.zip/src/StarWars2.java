
class StarWars2 {
    /*
     * Fight to the death between two ships.
     * On return one of the ships will be dead.
     * This method must NOT BE MODIFIED.
     */
    private void duel(SpaceShip x, SpaceShip t) {
        while(!x.isDead() && !t.isDead()) {
            x.hit(t.getWeapon());       
            if (x.isDead()) {
                System.out.println(x + " is dead");
            }
            else {
                t.hit(x.getWeapon());
                if (t.isDead()) {
                    System.out.println(t + " is dead");
                }
            }
        }
    }
    
    //check for next Tie
    private int nextTie(int i, SpaceShip[] fighters) {
        assert(i >= 0);
        while (i < fighters.length) {
            if (fighters[i] instanceof Tie) {
            	return i;
            }
            i++;
        }
        return -1;
    }
    
    //check for next XWing
    private int nextXWing(int i, SpaceShip[] fighters) {
        while (i < fighters.length) {
            if (fighters[i] instanceof XWing) {
                return i;
            }
            i++;
        }
        return -1;
    }
    /*
     * Simulate the battle between the XWing and Tie fighters in the given array.
     * @param the array of fighters, in no particular order.
     * The battle should proceed as it does in the StarWars class provided in the
     * reading. Specifically the first XWing in the array will battle the first Tie.
     * The winner of that will battle the next spaceship of the opposing type in the 
     * array, and so on.
     */
    void battle(SpaceShip[] fighters) {
	// to be completed
    	int numberOfGoodShips=0;
    	int numberOfBadShips=0;
    	int g = 0;
	    int e = 0;
	    int goodDeaths = 0;
	    int evilDeaths = 0;
	    XWing[] good;
	    Tie[] evil;
	    
	    for (int i=0;i<fighters.length;i++) {
	    	if (fighters[i] instanceof XWing)
	    		numberOfGoodShips++;
	    	else numberOfBadShips++;
	    }
	    good=new XWing[numberOfGoodShips];
	    evil=new Tie[numberOfBadShips];
	    
	    for (int i=0;i<good.length;i++) {
	    	good[i]=new XWing();
	    }
	    for (int i=0;i<evil.length;i++) {
	    	evil[i]=new Tie();
	    }
	     
	    	
	      while (g < good.length && e < evil.length) {
	         System.out.println("battling X-Wing #" + g + " versus Tie Fighter #" + e);
	         duel(good[g],evil[e]);
	         if (good[g].isDead()) {
	            g++;
	            goodDeaths++;
	         }
	         if (evil[e].isDead()) {
	            e++;
	            evilDeaths++;
	         }
	      }

	      int finalGood = good.length - goodDeaths;
	      int finalEvil = evil.length - evilDeaths;

	      System.out.println();
	      System.out.println("Battle Report:\t\tX-Wings\t\tTie Fighters");
	      System.out.println("------------------------------------------------------");
	      System.out.println();
	      System.out.println("Initial ships:\t\t" + good.length + "\t\t" + evil.length);
	      System.out.println();
	      System.out.println("Killed ships:\t\t"  + goodDeaths  + "\t\t" + evilDeaths);
	      System.out.println();
	      System.out.println("Final ships:\t\t"   + finalGood   + "\t\t" + finalEvil);
	      System.out.println();
	      if (finalGood > finalEvil) {
	         System.out.println("The rebel alliance is victorious!");
	      }
	      else {
	         System.out.println("The dark side has conquered!");
	      }
	      System.out.println();
	   }
    	
    	
    	
    	
    
}
