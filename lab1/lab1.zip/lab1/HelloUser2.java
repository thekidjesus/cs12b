//Jesus Munoz jmunoz10 12M
//This program is used by the Makefile

class HelloUser2{
	public static void main( String[] args ){
	System.out.println("Hello User, Welcome!");
	}
}