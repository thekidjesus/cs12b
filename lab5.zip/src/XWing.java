class XWing extends SpaceShip{

   public XWing() {

      shields = 1000;
      weapon  = 10;
   }
   public String toString() {
	   return "XWing";
   }

}